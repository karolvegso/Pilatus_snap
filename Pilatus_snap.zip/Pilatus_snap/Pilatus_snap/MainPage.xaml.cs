﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using System.Net;
using System.Net.Sockets;
using System.Threading;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Pilatus_snap
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void takeImageClick(object sender, RoutedEventArgs e)
        {
            // initialize IP address of Pilatus 200K and its port
            String server = ipAddress.Text;
            String portString = portNumber.Text;
            Int32 port = Int32.Parse(portString);

            // create new session with Pilatus 200K
            TcpClient session_Pilatus = new TcpClient(server, port);

            // initialize stream
            NetworkStream stream = session_Pilatus.GetStream();

            // set number of images
            String niString = "ni " + ni.Text + "\n";
            Byte[] data = System.Text.Encoding.ASCII.GetBytes(niString);
            stream.Write(data, 0, data.Length);
            // Buffer to store the response bytes.
            data = new Byte[256];
            // String to store the response ASCII representation.
            String responseData_ni = String.Empty;
            // Read Pilatus's response
            Int32 bytes = stream.Read(data, 0, data.Length);
            responseData_ni = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
            data = null;
            Thread.Sleep(250);

            // set exposure time
            String exptString = "expt " + expt.Text + "\n";
            data = System.Text.Encoding.ASCII.GetBytes(exptString);
            stream.Write(data, 0, data.Length);
            // Read Pilatus's response
            data = new Byte[256];
            // String to store the response ASCII representation.
            String responseData_expt = String.Empty;
            bytes = stream.Read(data, 0, data.Length);
            responseData_expt = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
            data = null;
            Thread.Sleep(250);

            // set exposure period
            String exppString = "expp " + expp.Text + "\n";
            data = System.Text.Encoding.ASCII.GetBytes(exppString);
            stream.Write(data, 0, data.Length);
            // Read Pilatus's response
            data = new Byte[256];
            // String to store the response ASCII representation.
            String responseData_expp = String.Empty;
            // Read Pilatus's response
            bytes = stream.Read(data, 0, data.Length);
            responseData_expp = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
            data = null;
            Thread.Sleep(250);

            // take image, do exposure
            String expoString = "expo " + imageName.Text + ".tif" + "\n";
            data = System.Text.Encoding.ASCII.GetBytes(expoString);
            stream.Write(data, 0, data.Length);
            // Read Pilatus's response
            data = new Byte[256];
            // String to store the response ASCII representation.
            String responseData_expo = String.Empty;
            // Read Pilatus's response
            bytes = stream.Read(data, 0, data.Length);
            responseData_expo = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
            data = null;
            Thread.Sleep(250);

            pilatusResponse.Text = responseData_ni + responseData_expt + responseData_expp + responseData_expo;

            Int32 niNumber = Int32.Parse(ni.Text);
            float niFloatNumber = Convert.ToSingle(niNumber);
            float exppFloatNumber = float.Parse(expp.Text);
            float wait_in_ms_FloatNumber = niFloatNumber * exppFloatNumber * 1000 + 1000;
            Int32 wait_in_ms = Convert.ToInt32(wait_in_ms_FloatNumber);
            Thread.Sleep(wait_in_ms);

            // Close everything
            stream.Flush();
            stream.Close();
            session_Pilatus.Close();
        }

        private void setthresholdButtonClick(object sender, RoutedEventArgs e)
        {
            // initialize IP address of Pilatus 200K and its port
            String server = ipAddress.Text;
            String portString = portNumber.Text;
            Int32 port = Int32.Parse(portString);

            // create new session with Pilatus 200K
            TcpClient session_Pilatus = new TcpClient(server, port);

            // initialize stream
            NetworkStream stream = session_Pilatus.GetStream();

            // set number of images
            String setthresholdString = setthreshold_cmd.Text + "\n";
            Byte[] data = System.Text.Encoding.ASCII.GetBytes(setthresholdString);
            stream.Write(data, 0, data.Length);
            // Buffer to store the response bytes.
            data = new Byte[256];
            // String to store the response ASCII representation.
            String responseData_setthreshold = String.Empty;
            // Read Pilatus's response
            Int32 bytes = stream.Read(data, 0, data.Length);
            responseData_setthreshold = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
            data = null;
            pilatusResponse.Text = responseData_setthreshold;
            Thread.Sleep(250);

            // Close everything
            stream.Flush();
            stream.Close();
            session_Pilatus.Close();
        }
    }
}
