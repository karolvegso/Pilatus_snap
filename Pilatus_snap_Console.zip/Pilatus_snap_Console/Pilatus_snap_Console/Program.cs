﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Pilatus_snap_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            // initialize IP address of Pilatus 200K and its port
            String server = args[0];
            String portString = args[1];
            Int32 port = Int32.Parse(portString);

            // print server and port on the screen
            // print IP address of Pilatus detector
            Console.WriteLine("IP address of Pilatus detector is: ");
            Console.WriteLine(server);
            // print port of Pilatus detcetor
            Console.WriteLine("Port of Pilatus detector is: ");
            Console.WriteLine(portString);

            // create new session with Pilatus 200K
            TcpClient session_Pilatus = new TcpClient(server, port);

            // initialize stream
            NetworkStream stream = session_Pilatus.GetStream();

            // set number of images
            // print number of images
            Console.WriteLine("Number of images is: ");
            Console.WriteLine(args[2]);
            String niString = "ni " + args[2] + "\n";
            Byte[] data = System.Text.Encoding.ASCII.GetBytes(niString);
            stream.Write(data, 0, data.Length);
            // Buffer to store the response bytes.
            data = new Byte[256];
            // String to store the response ASCII representation.
            String responseData_ni = String.Empty;
            // Read Pilatus's response
            Int32 bytes = stream.Read(data, 0, data.Length);
            responseData_ni = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
            data = null;
            Thread.Sleep(250);

            // set exposure time
            // print exposure time
            Console.WriteLine("Exposure time is: ");
            Console.WriteLine(args[3]);
            String exptString = "expt " + args[3] + "\n";
            data = System.Text.Encoding.ASCII.GetBytes(exptString);
            stream.Write(data, 0, data.Length);
            // Read Pilatus's response
            data = new Byte[256];
            // String to store the response ASCII representation.
            String responseData_expt = String.Empty;
            bytes = stream.Read(data, 0, data.Length);
            responseData_expt = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
            data = null;
            Thread.Sleep(250);

            // set exposure period
            // print exposure period
            Console.WriteLine("Exposure period is: ");
            Console.WriteLine(args[4]);
            String exppString = "expp " + args[4] + "\n";
            data = System.Text.Encoding.ASCII.GetBytes(exppString);
            stream.Write(data, 0, data.Length);
            // Read Pilatus's response
            data = new Byte[256];
            // String to store the response ASCII representation.
            String responseData_expp = String.Empty;
            // Read Pilatus's response
            bytes = stream.Read(data, 0, data.Length);
            responseData_expp = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
            data = null;
            Thread.Sleep(250);

            // take image, do exposure
            String expoString = "expo " + args[5] + ".tif" + "\n";
            // print expo command
            Console.WriteLine("Exposition command is: ");
            Console.WriteLine(expoString);
            data = System.Text.Encoding.ASCII.GetBytes(expoString);
            stream.Write(data, 0, data.Length);
            // Read Pilatus's response
            data = new Byte[256];
            // String to store the response ASCII representation.
            String responseData_expo = String.Empty;
            // Read Pilatus's response
            bytes = stream.Read(data, 0, data.Length);
            responseData_expo = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
            data = null;
            Thread.Sleep(250);

            // print all responses
            Console.WriteLine(responseData_ni);
            Console.WriteLine(responseData_expt);
            Console.WriteLine(responseData_expp);
            Console.WriteLine(responseData_expo);

            Int32 niNumber = Int32.Parse(args[2]);
            float niFloatNumber = Convert.ToSingle(niNumber);
            float exppFloatNumber = float.Parse(args[4]);
            float wait_in_ms_FloatNumber = niFloatNumber * exppFloatNumber * 1000 + 1000;
            Int32 wait_in_ms = Convert.ToInt32(wait_in_ms_FloatNumber);
            Thread.Sleep(wait_in_ms);

            // Close everything
            stream.Flush();
            stream.Close();
            session_Pilatus.Close();
        }
    }
}
